<?php
// Mengaktifkan session php
session_start();

// Menghubungkan dengan koneksi
include '../koneksi.php';

// Menangkap data yang dikirim dari form
$email = mysqli_real_escape_string($koneksi, $_POST['email']);
$pass = mysqli_real_escape_string($koneksi, $_POST['pass']);

// Menyeleksi data admin dengan username dan password yang sesuai
$data = mysqli_query($koneksi, "SELECT * FROM user WHERE email='$email' AND pass='$pass'");

// Menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($data);

if ($cek > 0) {
    $sesi = mysqli_fetch_assoc($data);
    $role_id = $sesi['role'];
    if($role_id==1){
        $role_query = mysqli_query($koneksi, "SELECT nama FROM role WHERE id_role='$role_id'");
        $role_data = mysqli_fetch_assoc($role_query);
        $role_name = $role_data['nama'];
    
        // Menyimpan informasi ke dalam session
        $_SESSION['id'] = $sesi['id_user'];
        $_SESSION['nama'] = $sesi['nama'];
        $_SESSION['role_id'] = $role_id;
        $_SESSION['role_name'] = $role_name; // Menyimpan nama role ke session
        $_SESSION['status'] = "login";
    
        header("location:../halaman/index.php");
    }
    else if($role_id==2){
        $role_query = mysqli_query($koneksi, "SELECT nama FROM role WHERE id_role='$role_id'");
        $role_data = mysqli_fetch_assoc($role_query);
        $role_name = $role_data['nama'];
    
        // Menyimpan informasi ke dalam session
        $_SESSION['id'] = $sesi['id_user'];
        $_SESSION['nama'] = $sesi['nama'];
        $_SESSION['role_id'] = $role_id;
        $_SESSION['role_name'] = $role_name; // Menyimpan nama role ke session
        $_SESSION['status'] = "login";
    
        header("location:../halaman/pimpinan.php");
    }
    else if($role_id==3){
        $role_query = mysqli_query($koneksi, "SELECT nama FROM role WHERE id_role='$role_id'");
        $role_data = mysqli_fetch_assoc($role_query);
        $role_name = $role_data['nama'];
    
        // Menyimpan informasi ke dalam session
        $_SESSION['id'] = $sesi['id_user'];
        $_SESSION['nama'] = $sesi['nama'];
        $_SESSION['role_id'] = $role_id;
        $_SESSION['role_name'] = $role_name; // Menyimpan nama role ke session
        $_SESSION['status'] = "login";
    
        header("location:../halaman/kepaladesa.php");
    }

    // Query untuk mendapatkan nama role berdasarkan role_id
    
} else {
    header("location:../login.php?pesan=gagal");
}
?>