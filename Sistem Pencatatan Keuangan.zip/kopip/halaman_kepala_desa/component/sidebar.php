<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item nav-profile">
            <a href="#" class="nav-link">
                <div class="nav-profile-image">
                    <img src="../assets/images/faces-clipart/pic-1.png" alt="profile">
                    <span class="login-status online"></span>
                    <!--change to offline or busy as needed-->
                </div>
                <div class="nav-profile-text d-flex flex-column">
                    <span class="font-weight-bold mb-2"><?=$_SESSION['nama']?></span>
                    <span class="text-secondary text-small"><?=$_SESSION['role_name']?></span>
                </div>

            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="index.php">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="../halaman_kepala_desa/pendapatan.php">
                <span class="menu-title">Pendapatan</span>
                <i class="mdi mdi-arrow-down-bold-hexagon-outline menu-icon"></i>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="../halaman_kepala_desa/pengeluaran.php">
                <span class="menu-title">Pengeluaran</span>
                <i class="mdi mdi-arrow-up-bold-hexagon-outline menu-icon"></i>
            </a>

        </li>


        <li class="nav-item">
            <a class="nav-link" href="../halaman_kepala_desa/laporan.php">
                <span class="menu-title">Laporan</span>
                <i class="mdi mdi-city menu-icon"></i>
            </a>



    </ul>
</nav>