<?php
//include('dbconnected.php');
include('koneksi.php');

$nama = $_GET['nama'];
$email = $_GET['email'];
$role = $_GET['role'];
$pass = $_GET['password'];

//query update
$query = mysqli_query($koneksi,"INSERT INTO `user` (`id_user`, `nama`,`pass`, `email`, `role`) VALUES (null, '$nama', '$pass', '$email', '$role')");

if ($query) {
 # credirect ke page index
 header("location:../../halaman/pengguna.php"); 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

//mysql_close($host);
?>