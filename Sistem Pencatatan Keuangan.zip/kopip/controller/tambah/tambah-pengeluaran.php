<?php
//include('dbconnected.php');
include('koneksi.php');

$tgl_pengeluaran = $_GET['tgl_pengeluaran'];
$jumlah = $_GET['jumlah'];
$unit_usaha = $_GET['unit_usaha'];
$kategori = $_GET['kategori'];

//query update
$query = mysqli_query($koneksi,"INSERT INTO `pengeluaran` (`tgl_pengeluaran`, `jumlah`, `id_unit_usaha`, `id_kategori`) VALUES ('$tgl_pengeluaran', '$jumlah', '$unit_usaha', '$kategori')");

if ($query) {
 # credirect ke page index
 header("location:../../halaman/pengeluaran.php"); 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

//mysql_close($host);
?>