<?php
//include('dbconnected.php');
include('koneksi.php');

$tgl_pemasukan = $_GET['tgl_pemasukan'];
$jumlah = $_GET['jumlah'];
$unit_usaha = $_GET['unit_usaha'];
$kategori = $_GET['kategori'];

//query update
$query = mysqli_query($koneksi,"INSERT INTO `pemasukan` (`tgl_pemasukan`, `jumlah`, `id_unit_usaha`, `id_kategori`) VALUES ('$tgl_pemasukan', '$jumlah', '$unit_usaha', '$kategori')");

if ($query) {
 # credirect ke page index
 header("location:../../halaman/pendapatan.php"); 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

//mysql_close($host);
?>