<?php
//include('dbconnected.php');
include('koneksi.php');

$id = $_GET['id_unit_usaha'];

//query update
$query = mysqli_query($koneksi,"DELETE FROM `unit_usaha` WHERE id_unit_usaha = '$id'");

if ($query) {
 # credirect ke page index
 header("location:../../halaman/unit_usaha.php"); 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

//mysql_close($host);
?>