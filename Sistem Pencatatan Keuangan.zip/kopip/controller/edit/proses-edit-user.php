<?php
//include('dbconnected.php');
include('koneksi.php');
$id = $_GET['id_user'];
$nama = $_GET['nama'];
$email = $_GET['email'];
$role = $_GET['role'];
$pass = $_GET['password'];

//query update
$query = mysqli_query($koneksi,"UPDATE user SET nama='$nama' , email='$email', role='$role', pass='$pass' WHERE id_user='$id' ");

if ($query) {
 # credirect ke page index
 header("location:../../halaman/pengguna.php"); 
}
else{
 echo "ERROR, data gagal diupdate". mysql_error();
}

//mysql_close($host);
?>