<?php
//include('dbconnected.php');
include('koneksi.php');

$id = $_GET['id_pengeluaran'];
$tgl = $_GET['tgl_pengeluaran'];
$jumlah = $_GET['jumlah'];
$unit_usaha = $_GET['id_unit_usaha'];
$kategori = $_GET['id_kategori'];

//query update
$query = mysqli_query($koneksi,"UPDATE pengeluaran SET tgl_pengeluaran='$tgl' , jumlah='$jumlah', id_unit_usaha='$unit_usaha', id_kategori='$kategori' WHERE id_pengeluaran='$id' ");

if ($query) {
 # credirect ke page index
 header("location:../../halaman/pengeluaran.php"); 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

//mysql_close($host);
?>