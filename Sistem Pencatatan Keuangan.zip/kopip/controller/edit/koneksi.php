<?php

$host = 'localhost';
$nama = 'root';
$pass = '';
$db = 'desa_trangsan';

$koneksi = mysqli_connect($host, $nama,$pass, $db);
?>