<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Data_Pemasukan.xls");
?>
<h3>Data Pemasukan</h3>    
<table border="1" cellpadding="5"> 
<tr>    
<th>ID Pemasukan</th>
<th>Tgl Pemasukan</th>
<th>Jumlah</th>    
<th>Nama Unit Usaha</th> 
<th>Nama Kategori</th> 
</tr>  
<?php  
// Load file koneksi.php  
include "koneksi.php";    
// Buat query untuk menampilkan semua data siswa 
$query = "SELECT pemasukan.id_pemasukan, pemasukan.tgl_pemasukan, pemasukan.jumlah, unit_usaha.nama AS nama_unit_usaha, kategori.nama AS nama_kategori
          FROM pemasukan
          INNER JOIN unit_usaha ON pemasukan.id_unit_usaha = unit_usaha.id_unit_usaha
          INNER JOIN kategori ON pemasukan.id_kategori = kategori.id_kategori";
$result = mysqli_query($koneksi, $query);
// Untuk penomoran tabel, di awal set dengan 1 
while($data = mysqli_fetch_array($result)){ 
    // Ambil semua data dari hasil eksekusi $sql 
    echo "<tr>";    
    echo "<td>".$data['id_pemasukan']."</td>";   
    echo "<td>".$data['tgl_pemasukan']."</td>";    
    echo "<td>".$data['jumlah']."</td>";    
    echo "<td>".$data['nama_unit_usaha']."</td>";      
    echo "<td>".$data['nama_kategori']."</td>";      
    echo "</tr>";        
}  
?>
</table>
