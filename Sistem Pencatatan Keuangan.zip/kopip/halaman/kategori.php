<?php
require '../cek-sesi.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Purple Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../assets/vendors/css/vendor.bundle.base.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../assets/images/favicon.png" />
</head>

<body>
    <div class="container-scroller">

    </div>
    <!-- partial:partials/_navbar.html -->
    <?php require '../component/navbar.php'?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <?php require '../component/sidebar.php'?>

        <!-- partial -->
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="page-header">
                    <h3 class="page-title">
                        <span class="page-title-icon bg-gradient-primary text-white me-2">
                            <i class="mdi mdi-arrow-down-bold-hexagon-outline"></i>
                        </span> Kategori
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item active" aria-current="page">
                                <span></span>Overview <i
                                    class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-12 grid-margin stretch-card">
                    <div class="card">

                        <div class="card-body">
                            <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                data-bs-target="#myModalTambah"><i class="mdi mdi-arrow-down-bold-hexagon-outline">
                                    Tambah Kategori</i></button><br><br>
                            <h4 class="card-title">Tabel Kategori</h4>

                            </p>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th>Keterangan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>Nama</th>
                                        <th>Keterangan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php 
$query = mysqli_query($koneksi,"SELECT * FROM kategori");
$no = 1;
while ($data = mysqli_fetch_assoc($query)) 
{
?>
                                    <tr>
                                        <td><?=$data['nama']?></td>
                                        <td><?=$data['keterangan']?></td>


                                        <td>
                                            <!-- Button untuk modal -->
                                            <a href="#" type="button"
                                                class=" mdi mdi-tooltip-edit btn btn-primary btn-md"
                                                data-bs-toggle="modal"
                                                data-bs-target="#myModal<?php echo $data['id_kategori']; ?>"> Edit</a>
                                        </td>
                                    </tr>
                                    <!-- Modal Edit Mahasiswa-->
                                    <div class="modal fade" id="myModal<?php echo $data['id_kategori']; ?>"
                                        role="dialog">
                                        <div class="modal-dialog">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Ubah Data Unit Usaha</h4>
                                                    <button type="button" class="close"
                                                        data-bs-dismiss="modal">&times;</button>
                                                </div>
                                                <div class="modal-body">
                                                    <form role="form"
                                                        action="../controller/edit/proses-edit-kategori.php"
                                                        method="get">

                                                        <?php
$id = $data['id_kategori']; 
$query_edit = mysqli_query($koneksi,"SELECT * FROM kategori WHERE id_kategori='$id'");
//$result = mysqli_query($conn, $query);
while ($row = mysqli_fetch_array($query_edit)) {  
?>


                                                        <input type="hidden" name="id_kategori"
                                                            value="<?php echo $row['id_kategori']; ?>">

                                                        <div class="form-group">
                                                            <label>Id</label>
                                                            <input type="text" name="id_kategori" class="form-control"
                                                                value="<?php echo $row['id_kategori']; ?>" disabled>
                                                        </div>


                                                        <div class="form-group">
                                                            <label>Nama</label>
                                                            <input type="text" name="nama" class="form-control"
                                                                value="<?php echo $row['nama']; ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Keterangan</label>
                                                            <input type="text" name="keterangan" class="form-control"
                                                                value="<?php echo $row['keterangan']; ?>">
                                                        </div>




                                                </div>

                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-success">Ubah</button>
                                                    <a href="../controller/hapus/hapus-kategori.php?id_kategori=<?=$row['id_kategori'];?>"
                                                        Onclick="confirm('Anda Yakin Ingin Menghapus?')"
                                                        class="btn btn-danger">Hapus</a>
                                                    <button type="button" class="btn btn-default"
                                                        data-bs-dismiss="modal">Keluar</button>
                                                </div>
                                                <?php 
}
//mysql_close($host);
?>

                                                </form>
                                            </div>
                                        </div>

                                    </div>
                        </div>



                        <!-- Modal -->
                        <div id="myModalTambah" class="modal fade" role="dialog">

                            <div class="modal-dialog">

                                <!-- konten modal-->
                                <div class="modal-content">
                                    <!-- heading modal -->
                                    <div class="modal-header">
                                        <h4 class="modal-title">Tambah Pengguna</h4>
                                        <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
                                    </div>
                                    <!-- body modal -->
                                    <form action="../controller/tambah/tambah-kategori.php" method="get">
                                        <div class="modal-body">
                                            Nama :
                                            <input type="text" class="form-control" name="nama">
                                            Keterangan :
                                            <input type="text" class="form-control" name="keterangan">
                                        </div>
                                        <!-- footer modal -->
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-success">Tambah</button>
                                    </form>
                                    <button type="button" class="btn btn-default"
                                        data-bs-dismiss="modal">Keluar</button>
                                </div>
                            </div>

                        </div>
                    </div>



                    <?php               
} 
?>
                    </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    </div>

    </div>
    </div>

    <!-- content-wrapper ends -->
    <?php require '../component/footer.php'?>
    </div>
    <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
        integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
        integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
    </script>
    <script src="../assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="assets/vendors/chart.js/Chart.min.js"></script>
    <script src="assets/js/jquery.cookie.js" type="text/javascript"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="../assets/js/modal.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/todolist.js"></script>

    <!-- End custom js for this page -->


    </script>
</body>

</html>