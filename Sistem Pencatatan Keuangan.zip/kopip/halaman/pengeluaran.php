<?php
require '../cek-sesi.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Purple Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../assets/vendors/css/vendor.bundle.base.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../assets/images/favicon.png" />
</head>

<body>
    <div class="container-scroller">

    </div>
    <!-- partial:partials/_navbar.html -->
    <?php require '../component/navbar.php'?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <?php require '../component/sidebar.php'?>

        <!-- partial -->
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="page-header">
                    <h3 class="page-title">
                        <span class="page-title-icon bg-gradient-primary text-white me-2">
                            <i class="mdi mdi-arrow-up-bold-hexagon-outline"></i>
                        </span> Pengeluaran
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item active" aria-current="page">
                                <span></span>Overview <i
                                    class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-12 grid-margin stretch-card">
                    <div class="card">

                        <div class="card-body">
                            <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                data-bs-target="#myModalTambah"><i class="mdi mdi-arrow-up-bold-hexagon-outline"> Tambah
                                    Pengeluaran</i></button><br><br>
                            <h4 class="card-title">Tabel Pengeluaran</h4>

                            </p>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ID Pemasukan</th>
                                        <th>Unit Usaha</th>
                                        <th>Kategori</th>
                                        <th>Tanggal</th>
                                        <th>Jumlah</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>ID Pemasukan</th>
                                        <th>Unit Usaha</th>
                                        <th>Kategori</th>
                                        <th>Tanggal</th>
                                        <th>Jumlah</th>
                                        <th>Aksi</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php 
$query = mysqli_query($koneksi,"SELECT * FROM pengeluaran");
$no = 1;
while ($data = mysqli_fetch_assoc($query)) 
{
?>
                                    <tr>
                                        <td><?=$data['id_pengeluaran']?></td>
                                        <td>
                                            <?php
            $unit_usaha_query = mysqli_query($koneksi, "SELECT nama FROM unit_usaha WHERE id_unit_usaha = ".$data['id_unit_usaha']);
            $unit_usaha_data = mysqli_fetch_assoc($unit_usaha_query);
            echo $unit_usaha_data['nama'];
        ?>
                                        </td>
                                        <td>
                                            <?php
            $unit_usaha_query = mysqli_query($koneksi, "SELECT nama FROM kategori WHERE id_kategori = ".$data['id_kategori']);
            $unit_usaha_data = mysqli_fetch_assoc($unit_usaha_query);
            echo $unit_usaha_data['nama'];
        ?>
                                        </td>
                                        <td><?=$data['tgl_pengeluaran']?></td>
                                        <td>Rp. <?=number_format($data['jumlah'],2,',','.');?></td>

                                        <td>
                                            <!-- Button untuk modal -->
                                            <a href="#" type="button"
                                                class=" mdi mdi-tooltip-edit btn btn-primary btn-md"
                                                data-bs-toggle="modal"
                                                data-bs-target="#myModal<?php echo $data['id_pengeluaran']; ?>">
                                                Edit</a>
                                        </td>
                                    </tr>
                                    <!-- Modal Edit Mahasiswa-->
                                    <div class="modal fade" id="myModal<?php echo $data['id_pengeluaran']; ?>"
                                        role="dialog">
                                        <div class="modal-dialog">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Ubah Data Pengeluaran</h4>
                                                    <button type="button" class="close"
                                                        data-bs-dismiss="modal">&times;</button>
                                                </div>
                                                <div class="modal-body">
                                                    <form role="form"
                                                        action="../controller/edit/proses-edit-pengeluaran.php"
                                                        method="get">

                                                        <?php
$id = $data['id_pengeluaran']; 
$query_edit = mysqli_query($koneksi,"SELECT * FROM pengeluaran WHERE id_pengeluaran='$id'");
//$result = mysqli_query($conn, $query);
while ($row = mysqli_fetch_array($query_edit)) {  
?>


                                                        <input type="hidden" name="id_pengeluaran"
                                                            value="<?php echo $row['id_pengeluaran']; ?>">

                                                        <div class="form-group">
                                                            <label>Id</label>
                                                            <input type="text" name="id_pengeluaran"
                                                                class="form-control"
                                                                value="<?php echo $row['id_pengeluaran']; ?>" disabled>
                                                        </div>

                                                        <div class="form-group">
                                                            <label>Tanggal</label>
                                                            <input type="date" name="tgl_pengeluaran"
                                                                class="form-control"
                                                                value="<?php echo $row['tgl_pengeluaran']; ?>">
                                                        </div>

                                                        <div class="form-group">
                                                            <label>Jumlah</label>
                                                            <input type="text" name="jumlah" class="form-control"
                                                                value="<?php echo $row['jumlah']; ?>">
                                                        </div>

                                                        <div class="form-group">
                                                            <label>Unit Usaha</label>
                                                            <?php
if ($row['id_unit_usaha'] == 1){
	$querynama1 = mysqli_query($koneksi, "SELECT nama FROM unit_usaha where id_unit_usaha=1");
	$querynama1 = mysqli_fetch_array($querynama1);
} else if ($row['id_unit_usaha'] == 2){
	$querynama2 = mysqli_query($koneksi, "SELECT nama FROM unit_usaha where id_unit_usaha=2");
	$querynama2 = mysqli_fetch_array($querynama2);
} else if ($row['id_unit_usaha'] == 3){
	$querynama3 = mysqli_query($koneksi, "SELECT nama FROM unit_usaha where id_unit_usaha=3");
	$querynama3 = mysqli_fetch_array($querynama3);
} else if ($row['id_unit_usaha'] == 4){
	$querynama4 = mysqli_query($koneksi, "SELECT nama FROM unit_usaha where id_unit_usaha=4");
	$querynama4 = mysqli_fetch_array($querynama4);
}
 else if ($row['id_unit_usaha'] == 5){
	$querynama5 = mysqli_query($koneksi, "SELECT nama FROM unit_usaha where id_unit_usaha=5");
	$querynama5 = mysqli_fetch_array($querynama5);
}
?>


                                                            <select class="form-control" name='id_unit_usaha'>
                                                                <?php 
$queri = mysqli_query($koneksi, "SELECT * FROM unit_usaha");
	$no = 1;
	$noo = 1;
while($querynama = mysqli_fetch_array($queri)){

echo '<option value="'.$no++.'">'.$noo++.'.'.$querynama["nama"].'</option>';
}
?>
                                                            </select>


                                                        </div>
                                                        <div class="form-group">
                                                            <label>Unit Usaha</label>
                                                            <?php
if ($row['id_kategori'] == 1){
	$querynama1 = mysqli_query($koneksi, "SELECT nama FROM kategori where id_kategori=1");
	$querynama1 = mysqli_fetch_array($querynama1);
} else if ($row['id_kategori'] == 2){
	$querynama2 = mysqli_query($koneksi, "SELECT nama FROM kategori where id_kategori=2");
	$querynama2 = mysqli_fetch_array($querynama2);
} else if ($row['id_kategori'] == 3){
	$querynama3 = mysqli_query($koneksi, "SELECT nama FROM kategori where id_kategori=3");
	$querynama3 = mysqli_fetch_array($querynama3);
} else if ($row['id_kategori'] == 4){
	$querynama4 = mysqli_query($koneksi, "SELECT nama FROM kategori where id_kategori=4");
	$querynama4 = mysqli_fetch_array($querynama4);
}
 else if ($row['id_kategori'] == 5){
	$querynama5 = mysqli_query($koneksi, "SELECT nama FROM kategori where id_kategori=5");
	$querynama5 = mysqli_fetch_array($querynama5);
}
?>


                                                            <select class="form-control" name='id_kategori'>
                                                                <?php 
$queri = mysqli_query($koneksi, "SELECT * FROM kategori");
	$no = 1;
	$noo = 1;
while($querynama = mysqli_fetch_array($queri)){

echo '<option value="'.$no++.'">'.$noo++.'.'.$querynama["nama"].'</option>';
}
?>
                                                            </select>


                                                        </div>

                                                        <div class="modal-footer">
                                                            <button type="submit" class="btn btn-success">Ubah</button>
                                                            <a href="../controller/hapus/hapus-pengeluaran.php?id_pengeluaran=<?=$row['id_pengeluaran'];?>"
                                                                Onclick="confirm('Anda Yakin Ingin Menghapus?')"
                                                                class="btn btn-danger">Hapus</a>
                                                            <button type="button" class="btn btn-default"
                                                                data-bs-dismiss="modal">Keluar</button>
                                                        </div>
                                                        <?php 
}
//mysql_close($host);
?>

                                                    </form>
                                                </div>
                                            </div>

                                        </div>
                                    </div>



                                    <!-- Modal -->
                                    <div id="myModalTambah" class="modal fade" role="dialog">

                                        <div class="modal-dialog">

                                            <!-- konten modal-->
                                            <div class="modal-content">
                                                <!-- heading modal -->
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Tambah Pendapatan</h4>
                                                    <button type="button" class="close"
                                                        data-bs-dismiss="modal">&times;</button>
                                                </div>
                                                <!-- body modal -->
                                                <form action="../controller/tambah/tambah-pendapatan.php" method="get">
                                                    <div class="modal-body">
                                                        Tanggal :
                                                        <input type="date" class="form-control" name="tgl_pemasukan">
                                                        Jumlah :
                                                        <input type="number" class="form-control" name="jumlah">

                                                        Unit Usaha :
                                                        <select class="form-control" name="unit_usaha">
                                                            <?php
    // Periksa apakah query berhasil dieksekusi dan data ditemukan
    if ($result->num_rows > 0) {
        // Loop melalui setiap baris data
        while($row = $result->fetch_assoc()) {
            // Tampilkan setiap opsi dalam dropdown
            echo '<option value="' . $row["id_unit_usaha"] . '">' . $row["nama"] . '</option>';
        }
    } else {
        echo "Tidak ada data yang ditemukan dalam tabel 'unit_usaha'.";
    }
    ?>
                                                        </select>
                                                        Kategori :
                                                        <select class="form-control" name="kategori">
                                                            <?php
    // Periksa apakah query berhasil dieksekusi dan data ditemukan
    if ($result_kategori->num_rows > 0) {
        // Loop melalui setiap baris data
        while($row_kategori = $result_kategori->fetch_assoc()) {
            // Tampilkan setiap opsi dalam dropdown
            echo '<option value="' . $row_kategori["id_kategori"] . '">' . $row_kategori["nama"] . '</option>';
        }
    } else {
        echo "Tidak ada data yang ditemukan dalam tabel 'kategori'.";
    }
    ?>
                                                        </select>
                                                    </div>
                                                    <!-- footer modal -->
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-success">Tambah</button>
                                                </form>
                                                <button type="button" class="btn btn-default"
                                                    data-bs-dismiss="modal">Keluar</button>
                                            </div>
                                        </div>

                                    </div>
                        </div>



                        <?php               
} 
?>
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>
    </div>

    <!-- content-wrapper ends -->
    <?php require '../component/footer.php'?>
    </div>
    <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
        integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
        integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
    </script>
    <script src="../assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="assets/vendors/chart.js/Chart.min.js"></script>
    <script src="assets/js/jquery.cookie.js" type="text/javascript"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="../assets/js/modal.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/todolist.js"></script>

    <!-- End custom js for this page -->


    </script>
</body>

</html>