<?php
require '../cek-sesi.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Purple Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../assets/images/favicon.png" />
</head>

<body>
    <div class="container-scroller">
        <div class="row p-0 m-0 proBanner" id="proBanner">
            <div class="col-md-12 p-0 m-0">

            </div>
        </div>
        <!-- partial:partials/_navbar.html -->
        <?php require '../component/navbar.php'?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_sidebar.html -->
            <?php require '../component/sidebar.php'?>
            <?php
require ('../koneksi.php');

$karyawan = mysqli_query($koneksi, "SELECT * FROM karyawan");
$karyawan = mysqli_num_rows($karyawan);

$pengeluaran_hari_ini = mysqli_query($koneksi, "SELECT jumlah FROM pengeluaran where tgl_pengeluaran = CURDATE()");
$pengeluaran_hari_ini = mysqli_fetch_array($pengeluaran_hari_ini);
 
$pemasukan_hari_ini = mysqli_query($koneksi, "SELECT jumlah FROM pemasukan where tgl_pemasukan = CURDATE()");
$pemasukan_hari_ini = mysqli_fetch_array($pemasukan_hari_ini);



$pemasukan=mysqli_query($koneksi,"SELECT * FROM pemasukan");
while ($masuk=mysqli_fetch_array($pemasukan)){
$arraymasuk[] = $masuk['jumlah'];
}
$jumlahmasuk = array_sum($arraymasuk);


$pengeluaran=mysqli_query($koneksi,"SELECT * FROM pengeluaran");
while ($keluar=mysqli_fetch_array($pengeluaran)){
$arraykeluar[] = $keluar['jumlah'];
}
$jumlahkeluar = array_sum($arraykeluar);


$uang = $jumlahmasuk - $jumlahkeluar;

//untuk data chart area



$jumlahmasuk = array_sum(array_column(mysqli_fetch_all(mysqli_query($koneksi, "SELECT jumlah FROM pemasukan"), MYSQLI_ASSOC), 'jumlah'));
$jumlahkeluar = array_sum(array_column(mysqli_fetch_all(mysqli_query($koneksi, "SELECT jumlah FROM pengeluaran"), MYSQLI_ASSOC), 'jumlah'));

$uang = $jumlahmasuk - $jumlahkeluar;

$pendapatan_harian = [];
for ($i = 7; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $result = mysqli_query($koneksi, "SELECT jumlah FROM pemasukan WHERE tgl_pemasukan = '$date'");
    $row = mysqli_fetch_array($result);
    $pendapatan_harian[] = $row ? (int)$row['jumlah'] : 0;
}
?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="page-header">
                        <h3 class="page-title">
                            <span class="page-title-icon bg-gradient-primary text-white me-2">
                                <i class="mdi mdi-home"></i>
                            </span> Dashboard
                        </h3>
                        <nav aria-label="breadcrumb">
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item active" aria-current="page">
                                    <span></span>Overview <i
                                        class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <div class="row">
                        <div class="col-md-4 stretch-card grid-margin">
                            <div class="card bg-gradient-info card-img-holder text-white">
                                <div class="card-body">
                                    <img src="../assets/images/dashboard/circle.svg" class="card-img-absolute"
                                        alt="circle-image" />
                                    <h4 class="font-weight-normal mb-3">Pendapatan Hari ini <i
                                            class="mdi mdi-chart-line mdi-24px float-right"></i>
                                    </h4>
                                    <h2 class="mb-5"><?php
    if (isset($pemasukan_hari_ini['0'])) {
        $pemasukan = $pemasukan_hari_ini['0'];
    } else {
        $pemasukan = 0; // atau nilai default lainnya
    }
    echo "Rp. " . number_format($pemasukan, 2, ',', '.');
    ?></h2>
                                    <h6 class="card-text"> Pendapatan Mingguan: Rp.<?php
				echo number_format($jumlahmasuk,2,',','.');
				?></h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 stretch-card grid-margin">
                            <div class="card bg-gradient-danger card-img-holder text-white">
                                <div class="card-body">
                                    <img src="../assets/images/dashboard/circle.svg" class="card-img-absolute"
                                        alt="circle-image" />
                                    <h4 class="font-weight-normal mb-3">Pengeluaran Hari Ini <i
                                            class="mdi mdi-bookmark-outline mdi-24px float-right"></i>
                                    </h4>
                                    <h2 class="mb-5"><?php
    if (isset($pengeluaran_hari_ini['0'])) {
        $pengeluaran = $pengeluaran_hari_ini['0'];
    } else {
        $pengeluaran = 0; // atau nilai default lainnya
    }
    echo "Rp. " . number_format($pengeluaran, 2, ',', '.');
    ?></h2>
                                    <h6 class="card-text">Pengeluaran Mingguan : Rp.
                                        <?php
				echo number_format($jumlahkeluar,2,',','.');
				?></h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 stretch-card grid-margin">
                            <div class="card bg-gradient-success card-img-holder text-white">
                                <div class="card-body">
                                    <img src="../assets/images/dashboard/circle.svg" class="card-img-absolute"
                                        alt="circle-image" />
                                    <h4 class="font-weight-normal mb-3">Sisa Uang </i>
                                    </h4>
                                    <h2 class="mb-5">Rp.<?=number_format($uang,2,',','.');?></h2>
                                    <div class="progress progress-sm mr-2" style="height:20px">
                                        <?php
						  if ($uang < 1 ){
							  $warna = 'danger';
							  $value = 0;
						  }
						  else if ($uang >= 1 && $uang < 1000000){
						  $warna = 'warning';
						  $value = 1;
						  }
						  else{
							  $warna = 'info';
							  $value = $uang / 10000;
						  };
						  
						  ?>

                                        <div class="progress-bar bg-<?=$warna?>" role="progressbar" style="width: 100%"
                                            aria-valuenow="<?=$value?>" aria-valuemin="0" aria-valuemax="100">
                                            <span><?=$value?> % </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-7 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <div class="clearfix">
                                    <div class="row">
                                        <div class="card">
                                            <div class="card-body">
                                                <h4 class="card-title">Pendapatan Minggu Ini</h4>
                                                <div class="chart-container">
                                                    <canvas id="myAreaChart"></canvas>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Other chart or content -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Perbandingan</h4>
                                    <div class="chart-pie pt-4 pb-2">
                                        <canvas id="myPieChart"></canvas>
                                    </div>

                                    <div id="traffic-chart-legend"
                                        class="rounded-legend legend-vertical legend-bottom-left pt-4"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- content-wrapper ends -->
                    <?php require '../component/footer.php'?>
                </div>
                <!-- main-panel ends -->
            </div>
            <!-- page-body-wrapper ends -->
        </div>
        <!-- container-scroller -->
        <!-- plugins:js -->
        <script src="../assets/vendors/js/vendor.bundle.base.js"></script>
        <!-- endinject -->
        <!-- Plugin js for this page -->
        <script src="../assets/vendors/chart.js/Chart.min.js"></script>
        <script src="../assets/js/jquery.cookie.js" type="text/javascript"></script>
        <!-- End plugin js for this page -->
        <!-- inject:js -->
        <script src="../assets/js/off-canvas.js"></script>
        <script src="../assets/js/hoverable-collapse.js"></script>
        <script src="../assets/js/misc.js"></script>
        <!-- endinject -->
        <!-- Custom js for this page -->
        <script src="../assets/js/dashboard.js"></script>
        <script src="../assets/js/todolist.js"></script>

        <!-- End custom js for this page -->
        <script type="text/javascript">
        // Data from PHP
        var jumlahmasuk = <?php echo $jumlahmasuk / 1000000; ?>;
        var jumlahkeluar = <?php echo $jumlahkeluar / 1000000; ?>;
        var uang = <?php echo $uang / 1000000; ?>;

        // Chart.js setup
        var ctx = document.getElementById("myPieChart").getContext("2d");

        // Gradient colors
        var gradientStrokeBlue = ctx.createLinearGradient(0, 0, 0, 181);
        gradientStrokeBlue.addColorStop(0, "rgba(54, 215, 232, 1)");
        gradientStrokeBlue.addColorStop(1, "rgba(177, 148, 250, 1)");

        var gradientStrokeRed = ctx.createLinearGradient(0, 0, 0, 50);
        gradientStrokeRed.addColorStop(0, "rgba(255, 191, 150, 1)");
        gradientStrokeRed.addColorStop(1, "rgba(254, 112, 150, 1)");

        var gradientStrokeGreen = ctx.createLinearGradient(0, 0, 0, 300);
        gradientStrokeGreen.addColorStop(0, "rgba(6, 185, 157, 1)");
        gradientStrokeGreen.addColorStop(1, "rgba(132, 217, 210, 1)");

        // Legend colors
        var gradientLegendBlue = "linear-gradient(to right, rgba(54, 215, 232, 1), rgba(177, 148, 250, 1))";
        var gradientLegendRed = "linear-gradient(to right, rgba(255, 191, 150, 1), rgba(254, 112, 150, 1))";
        var gradientLegendGreen = "linear-gradient(to right, rgba(6, 185, 157, 1), rgba(132, 217, 210, 1))";

        // Chart data
        var trafficChartData = {
            datasets: [{
                data: [jumlahmasuk, jumlahkeluar, uang],
                backgroundColor: [gradientStrokeBlue, gradientStrokeGreen, gradientStrokeRed],
                hoverBackgroundColor: [gradientStrokeBlue, gradientStrokeGreen, gradientStrokeRed],
                borderColor: [gradientStrokeBlue, gradientStrokeGreen, gradientStrokeRed],
                legendColor: [gradientLegendBlue, gradientLegendGreen, gradientLegendRed],
            }],
            labels: ["Pendapatan", "Pengeluaran", "Sisa"],
        };

        // Chart options
        var trafficChartOptions = {
            responsive: true,
            animation: {
                animateScale: true,
                animateRotate: true,
            },
            legend: false,
            legendCallback: function(chart) {
                var text = [];
                text.push("<ul>");
                for (var i = 0; i < trafficChartData.datasets[0].data.length; i++) {
                    text.push('<li><span class="legend-dots" style="background:' + trafficChartData.datasets[0]
                        .legendColor[i] + '"></span>');
                    if (trafficChartData.labels[i]) {
                        text.push(trafficChartData.labels[i]);
                    }
                    text.push('<span class="float-right">' + trafficChartData.datasets[0].data[i] + "</span>");
                    text.push("</li>");
                }
                text.push("</ul>");
                return text.join("");
            },
        };

        // Initialize Chart
        var trafficChart = new Chart(ctx, {
            type: 'doughnut',
            data: trafficChartData,
            options: trafficChartOptions,
        });

        // Generate legend
        document.getElementById('traffic-chart-legend').innerHTML = trafficChart.generateLegend();
        </script>


        <script>
        // Data untuk chart dari PHP
        var pendapatanHarian = <?php echo json_encode($pendapatan_harian); ?>;

        function number_format(number, decimals, dec_point, thousands_sep) {
            number = (number + '').replace(',', '').replace(' ', '');
            var n = !isFinite(+number) ? 0 : +number,
                prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
                sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
                dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
                s = '',
                toFixedFix = function(n, prec) {
                    var k = Math.pow(10, prec);
                    return '' + Math.round(n * k) / k;
                };
            s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
            if (s[0].length > 3) {
                s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
            }
            if ((s[1] || '').length < prec) {
                s[1] = s[1] || '';
                s[1] += new Array(prec - s[1].length + 1).join('0');
            }
            return s.join(dec);
        }

        var ctx = document.getElementById("myAreaChart").getContext('2d');
        var myLineChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ["7 hari lalu", "6 hari lalu", "5 hari lalu", "4 hari lalu", "3 hari lalu",
                    "2 hari lalu",
                    "1 hari lalu"
                ],
                datasets: [{
                    label: "Pendapatan",
                    lineTension: 0.3,
                    backgroundColor: "rgba(78, 115, 223, 0.05)",
                    borderColor: "rgba(78, 115, 223, 1)",
                    pointRadius: 3,
                    pointBackgroundColor: "rgba(78, 115, 223, 1)",
                    pointBorderColor: "rgba(78, 115, 223, 1)",
                    pointHoverRadius: 3,
                    pointHoverBackgroundColor: "rgba(78, 115, 223, 1)",
                    pointHoverBorderColor: "rgba(78, 115, 223, 1)",
                    pointHitRadius: 10,
                    pointBorderWidth: 2,
                    data: pendapatanHarian,
                }],
            },
            options: {
                maintainAspectRatio: false,
                layout: {
                    padding: {
                        left: 10,
                        right: 25,
                        top: 25,
                        bottom: 0
                    }
                },
                scales: {
                    xAxes: [{
                        time: {
                            unit: 'date'
                        },
                        gridLines: {
                            display: false,
                            drawBorder: false
                        },
                        ticks: {
                            maxTicksLimit: 7
                        }
                    }],
                    yAxes: [{
                        ticks: {
                            maxTicksLimit: 5,
                            padding: 10,
                            callback: function(value, index, values) {
                                return 'Rp.' + number_format(value);
                            }
                        },
                        gridLines: {
                            color: "rgb(234, 236, 244)",
                            zeroLineColor: "rgb(234, 236, 244)",
                            drawBorder: false,
                            borderDash: [2],
                            zeroLineBorderDash: [2]
                        }
                    }],
                },
                legend: {
                    display: false
                },
                tooltips: {
                    backgroundColor: "rgb(255,255,255)",
                    bodyFontColor: "#858796",
                    titleMarginBottom: 10,
                    titleFontColor: '#6e707e',
                    titleFontSize: 14,
                    borderColor: '#dddfeb',
                    borderWidth: 1,
                    xPadding: 15,
                    yPadding: 15,
                    displayColors: false,
                    intersect: false,
                    mode: 'index',
                    caretPadding: 10,
                    callbacks: {
                        label: function(tooltipItem, chart) {
                            var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
                            return datasetLabel + ': Rp.' + number_format(tooltipItem.yLabel);
                        }
                    }
                }
            }
        });
        </script>

</body>

</html>