<?php
require '../cek-sesi.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Purple Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../assets/vendors/css/vendor.bundle.base.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../assets/images/favicon.png" />
</head>

<body>
    <div class="container-scroller">

    </div>
    <!-- partial:partials/_navbar.html -->
    <?php require './component/navbar.php'?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <?php require './component/sidebar.php'?>
        <?php
require ('../koneksi.php');

$karyawan = mysqli_query($koneksi, "SELECT * FROM karyawan");
$karyawan = mysqli_num_rows($karyawan);

$pengeluaran_hari_ini = mysqli_query($koneksi, "SELECT jumlah FROM pengeluaran where tgl_pengeluaran = CURDATE()");
$pengeluaran_hari_ini = mysqli_fetch_array($pengeluaran_hari_ini);
 
$pemasukan_hari_ini = mysqli_query($koneksi, "SELECT jumlah FROM pemasukan where tgl_pemasukan = CURDATE()");
$pemasukan_hari_ini = mysqli_fetch_array($pemasukan_hari_ini);



$pemasukan=mysqli_query($koneksi,"SELECT * FROM pemasukan");
while ($masuk=mysqli_fetch_array($pemasukan)){
$arraymasuk[] = $masuk['jumlah'];
}
$jumlahmasuk = array_sum($arraymasuk);


$pengeluaran=mysqli_query($koneksi,"SELECT * FROM pengeluaran");
while ($keluar=mysqli_fetch_array($pengeluaran)){
$arraykeluar[] = $keluar['jumlah'];
}
$jumlahkeluar = array_sum($arraykeluar);


$uang = $jumlahmasuk - $jumlahkeluar;

//untuk data chart area



$sekarang =mysqli_query($koneksi, "SELECT jumlah FROM pemasukan
WHERE tgl_pemasukan = CURDATE()");
$sekarang = mysqli_fetch_array($sekarang);

$satuhari =mysqli_query($koneksi, "SELECT jumlah FROM pemasukan
WHERE tgl_pemasukan = CURDATE() - INTERVAL 1 DAY");
$satuhari= mysqli_fetch_array($satuhari);


$duahari =mysqli_query($koneksi, "SELECT jumlah FROM pemasukan
WHERE tgl_pemasukan = CURDATE() - INTERVAL 2 DAY");
$duahari= mysqli_fetch_array($duahari);

$tigahari =mysqli_query($koneksi, "SELECT jumlah FROM pemasukan
WHERE tgl_pemasukan = CURDATE() - INTERVAL 3 DAY");
$tigahari= mysqli_fetch_array($tigahari);

$empathari =mysqli_query($koneksi, "SELECT jumlah FROM pemasukan
WHERE tgl_pemasukan = CURDATE() - INTERVAL 4 DAY");
$empathari= mysqli_fetch_array($empathari);

$limahari =mysqli_query($koneksi, "SELECT jumlah FROM pemasukan
WHERE tgl_pemasukan = CURDATE() - INTERVAL 5 DAY");
$limahari= mysqli_fetch_array($limahari);

$enamhari =mysqli_query($koneksi, "SELECT jumlah FROM pemasukan
WHERE tgl_pemasukan = CURDATE() - INTERVAL 6 DAY");
$enamhari= mysqli_fetch_array($enamhari);

$tujuhhari =mysqli_query($koneksi, "SELECT jumlah FROM pemasukan
WHERE tgl_pemasukan = CURDATE() - INTERVAL 7 DAY");
$tujuhhari= mysqli_fetch_array($tujuhhari);
?>
        <!-- partial -->
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="page-header">
                    <h3 class="page-title">
                        <span class="page-title-icon bg-gradient-primary text-white me-2">
                            <i class="mdi mdi-arrow-down-bold-hexagon-outline"></i>
                        </span> Pendapatan
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item active" aria-current="page">
                                <span></span>Overview <i
                                    class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-12 grid-margin stretch-card">
                    <div class="card">

                        <div class="card-body">

                            <h4 class="card-title">Tabel Pemasukan</h4>

                            </p>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ID Pemasukan</th>
                                        <th>Unit Usaha</th>
                                        <th>Kategori</th>
                                        <th>Tanggal</th>
                                        <th>Jumlah</th>

                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>ID Pemasukan</th>
                                        <th>Unit Usaha</th>
                                        <th>Kategori</th>
                                        <th>Tanggal</th>
                                        <th>Jumlah</th>

                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php 
$query = mysqli_query($koneksi,"SELECT * FROM pemasukan");
$no = 1;
while ($data = mysqli_fetch_assoc($query)) 
{
?>
                                    <tr>
                                        <td><?=$data['id_pemasukan']?></td>
                                        <td>
                                            <?php
            $unit_usaha_query = mysqli_query($koneksi, "SELECT nama FROM unit_usaha WHERE id_unit_usaha = ".$data['id_unit_usaha']);
            $unit_usaha_data = mysqli_fetch_assoc($unit_usaha_query);
            echo $unit_usaha_data['nama'];
        ?>
                                        </td>
                                        <td>
                                            <?php
            $unit_usaha_query = mysqli_query($koneksi, "SELECT nama FROM kategori WHERE id_kategori = ".$data['id_kategori']);
            $unit_usaha_data = mysqli_fetch_assoc($unit_usaha_query);
            echo $unit_usaha_data['nama'];
        ?>
                                        </td>
                                        <td><?=$data['tgl_pemasukan']?></td>
                                        <td>Rp. <?=number_format($data['jumlah'],2,',','.');?></td>


                                    </tr>
                                    <!-- Modal Edit Mahasiswa-->
                                    <div class="modal fade" id="myModal<?php echo $data['id_pemasukan']; ?>"
                                        role="dialog">
                                        <div class="modal-dialog">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Ubah Data Pemasukan</h4>
                                                    <button type="button" class="close"
                                                        data-bs-dismiss="modal">&times;</button>
                                                </div>
                                                <div class="modal-body">
                                                    <form role="form"
                                                        action="../controller/edit/proses-edit-pemasukan.php"
                                                        method="get">

                                                        <?php
$id = $data['id_pemasukan']; 
$query_edit = mysqli_query($koneksi,"SELECT * FROM pemasukan WHERE id_pemasukan='$id'");
//$result = mysqli_query($conn, $query);
while ($row = mysqli_fetch_array($query_edit)) {  
?>


                                                        <input type="hidden" name="id_pemasukan"
                                                            value="<?php echo $row['id_pemasukan']; ?>">

                                                        <div class="form-group">
                                                            <label>Id</label>
                                                            <input type="text" name="id_pemasukan" class="form-control"
                                                                value="<?php echo $row['id_pemasukan']; ?>" disabled>
                                                        </div>

                                                        <div class="form-group">
                                                            <label>Tanggal</label>
                                                            <input type="date" name="tgl_pemasukan" class="form-control"
                                                                value="<?php echo $row['tgl_pemasukan']; ?>">
                                                        </div>

                                                        <div class="form-group">
                                                            <label>Jumlah</label>
                                                            <input type="text" name="jumlah" class="form-control"
                                                                value="<?php echo $row['jumlah']; ?>">
                                                        </div>

                                                        <div class="form-group">
                                                            <label>Unit Usaha</label>
                                                            <?php
if ($row['id_unit_usaha'] == 1){
	$querynama1 = mysqli_query($koneksi, "SELECT nama FROM unit_usaha where id_unit_usaha=1");
	$querynama1 = mysqli_fetch_array($querynama1);
} else if ($row['id_unit_usaha'] == 2){
	$querynama2 = mysqli_query($koneksi, "SELECT nama FROM unit_usaha where id_unit_usaha=2");
	$querynama2 = mysqli_fetch_array($querynama2);
} else if ($row['id_unit_usaha'] == 3){
	$querynama3 = mysqli_query($koneksi, "SELECT nama FROM unit_usaha where id_unit_usaha=3");
	$querynama3 = mysqli_fetch_array($querynama3);
} else if ($row['id_unit_usaha'] == 4){
	$querynama4 = mysqli_query($koneksi, "SELECT nama FROM unit_usaha where id_unit_usaha=4");
	$querynama4 = mysqli_fetch_array($querynama4);
}
 else if ($row['id_unit_usaha'] == 5){
	$querynama5 = mysqli_query($koneksi, "SELECT nama FROM unit_usaha where id_unit_usaha=5");
	$querynama5 = mysqli_fetch_array($querynama5);
}
?>


                                                            <select class="form-control" name='id_unit_usaha'>
                                                                <?php 
$queri = mysqli_query($koneksi, "SELECT * FROM unit_usaha");
	$no = 1;
	$noo = 1;
while($querynama = mysqli_fetch_array($queri)){

echo '<option value="'.$no++.'">'.$noo++.'.'.$querynama["nama"].'</option>';
}
?>
                                                            </select>


                                                        </div>
                                                        <div class="form-group">
                                                            <label>Unit Usaha</label>
                                                            <?php
if ($row['id_kategori'] == 1){
	$querynama1 = mysqli_query($koneksi, "SELECT nama FROM kategori where id_kategori=1");
	$querynama1 = mysqli_fetch_array($querynama1);
} else if ($row['id_kategori'] == 2){
	$querynama2 = mysqli_query($koneksi, "SELECT nama FROM kategori where id_kategori=2");
	$querynama2 = mysqli_fetch_array($querynama2);
} else if ($row['id_kategori'] == 3){
	$querynama3 = mysqli_query($koneksi, "SELECT nama FROM kategori where id_kategori=3");
	$querynama3 = mysqli_fetch_array($querynama3);
} else if ($row['id_kategori'] == 4){
	$querynama4 = mysqli_query($koneksi, "SELECT nama FROM kategori where id_kategori=4");
	$querynama4 = mysqli_fetch_array($querynama4);
}
 else if ($row['id_kategori'] == 5){
	$querynama5 = mysqli_query($koneksi, "SELECT nama FROM kategori where id_kategori=5");
	$querynama5 = mysqli_fetch_array($querynama5);
}
?>


                                                            <select class="form-control" name='id_kategori'>
                                                                <?php 
$queri = mysqli_query($koneksi, "SELECT * FROM kategori");
	$no = 1;
	$noo = 1;
while($querynama = mysqli_fetch_array($queri)){

echo '<option value="'.$no++.'">'.$noo++.'.'.$querynama["nama"].'</option>';
}
?>
                                                            </select>


                                                        </div>

                                                        <div class="modal-footer">
                                                            <button type="submit" class="btn btn-success">Ubah</button>
                                                            <a href="../controller/hapus/hapus-pemasukan.php?id_pemasukan=<?=$row['id_pemasukan'];?>"
                                                                Onclick="confirm('Anda Yakin Ingin Menghapus?')"
                                                                class="btn btn-danger">Hapus</a>
                                                            <button type="button" class="btn btn-default"
                                                                data-bs-dismiss="modal">Keluar</button>
                                                        </div>
                                                        <?php 
}
//mysql_close($host);
?>

                                                    </form>
                                                </div>
                                            </div>

                                        </div>
                                    </div>



                                    <!-- Modal -->
                                    <div id="myModalTambah" class="modal fade" role="dialog">

                                        <div class="modal-dialog">

                                            <!-- konten modal-->
                                            <div class="modal-content">
                                                <!-- heading modal -->
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Tambah Pendapatan</h4>
                                                    <button type="button" class="close"
                                                        data-bs-dismiss="modal">&times;</button>
                                                </div>
                                                <!-- body modal -->
                                                <form action="../controller/tambah/tambah-pendapatan.php" method="get">
                                                    <div class="modal-body">
                                                        Tanggal :
                                                        <input type="date" class="form-control" name="tgl_pemasukan">
                                                        Jumlah :
                                                        <input type="number" class="form-control" name="jumlah">

                                                        Unit Usaha :
                                                        <select class="form-control" name="unit_usaha">
                                                            <?php
    // Periksa apakah query berhasil dieksekusi dan data ditemukan
    if ($result->num_rows > 0) {
        // Loop melalui setiap baris data
        while($row = $result->fetch_assoc()) {
            // Tampilkan setiap opsi dalam dropdown
            echo '<option value="' . $row["id_unit_usaha"] . '">' . $row["nama"] . '</option>';
        }
    } else {
        echo "Tidak ada data yang ditemukan dalam tabel 'unit_usaha'.";
    }
    ?>
                                                        </select>
                                                        Kategori :
                                                        <select class="form-control" name="kategori">
                                                            <?php
    // Periksa apakah query berhasil dieksekusi dan data ditemukan
    if ($result_kategori->num_rows > 0) {
        // Loop melalui setiap baris data
        while($row_kategori = $result_kategori->fetch_assoc()) {
            // Tampilkan setiap opsi dalam dropdown
            echo '<option value="' . $row_kategori["id_kategori"] . '">' . $row_kategori["nama"] . '</option>';
        }
    } else {
        echo "Tidak ada data yang ditemukan dalam tabel 'kategori'.";
    }
    ?>
                                                        </select>
                                                    </div>
                                                    <!-- footer modal -->
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-success">Tambah</button>
                                                </form>
                                                <button type="button" class="btn btn-default"
                                                    data-bs-dismiss="modal">Keluar</button>
                                            </div>
                                        </div>

                                    </div>
                        </div>



                        <?php               
} 
?>
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>
    </div>

    <!-- content-wrapper ends -->
    <?php require '../component/footer.php'?>
    </div>
    <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
        integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
        integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
    </script>
    <script src="../assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="assets/vendors/chart.js/Chart.min.js"></script>
    <script src="assets/js/jquery.cookie.js" type="text/javascript"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="../assets/js/modal.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/todolist.js"></script>

    <!-- End custom js for this page -->


    </script>
</body>

</html>