	<!-- cek apakah sudah login -->
	<?php 
	session_start();
	require 'koneksi.php';
	if($_SESSION['status']!="login"){
		header("location:login.php?pesan=belum_login");
	}
	$sql = "SELECT id_unit_usaha, nama, keterangan FROM unit_usaha";
	$result = $koneksi->query($sql);
	
	$sql_kategori = "SELECT id_kategori, nama FROM kategori";
$result_kategori = $koneksi->query($sql_kategori);
	
$sql_role = "SELECT id_role, nama FROM role";
$result_role = $koneksi->query($sql_role);

?>
