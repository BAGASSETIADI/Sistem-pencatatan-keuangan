<ul class="navbar-nav navbar-nav-right">
    <li class="nav-item nav-profile dropdown">
        <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-bs-toggle="dropdown"
            aria-expanded="false">

            <div class="nav-profile-text">
                <p class="mb-1 text-black"><?=$_SESSION['nama']?></p>
            </div>
        </a>
        <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">

            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="../login.php">
                <i class="mdi mdi-logout me-2 text-primary"></i> Signout </a>
        </div>
    </li>