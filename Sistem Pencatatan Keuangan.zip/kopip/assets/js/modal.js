// Dapatkan elemen modal
var modal = document.getElementById("myModal");

// Dapatkan elemen tombol tutup
var closeBtn = document.getElementsByClassName("close")[0];

// Ketika pengguna klik tombol buka modal, tampilkan modal
function openModal() {
  modal.style.display = "block";
}

// Ketika pengguna klik tombol tutup, sembunyikan modal
closeBtn.onclick = function () {
  modal.style.display = "none";
};

// Ketika pengguna klik di luar area modal, sembunyikan modal
window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};
